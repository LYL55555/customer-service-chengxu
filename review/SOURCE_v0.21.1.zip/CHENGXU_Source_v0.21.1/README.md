# 澄序源码 0.21.1

当前源码从本目录运行，完整说明见RUN_THIS_FIRST.md。Python 3.10以上，先安装requirements.txt，执行python3 app.py，打开http://127.0.0.1:8765/。未配置模型会明确提示；本地.env只按CONFIG_TEMPLATE.txt自行填写，不提交key。

保存原文回放可运行python3 scripts/load_submission_demo.py，不需要模型key；真实生成需要自己的接口配置。新建客户只填称呼，选场景、截图或聊天，生成后选一条复制。

外层材料包index.html是评审入口，含A—E材料、原50/150、版本与限制。源码不含运行客户库、任何.env、缓存或原题。Pro未接入，N16已认可结束；其他已知编辑/校验限制见外层D/E报告。本源码为本地原型，不是生产CRM。
