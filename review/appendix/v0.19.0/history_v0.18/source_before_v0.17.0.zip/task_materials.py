import re

VERSION = 'task-materials-1.0.0'
TASKS = [
    ('bulky_folder', r'文件夹|厚.{0,4}(?:文件|资料)', '先回答已知A4容量；厚文件夹的长宽厚才是必要补充。向客户自然了解，不列内尺寸和包口资料缺项。', ['a4_fit', 'dimensions_cm']),
    ('stock_reservation', r'库存|有货|留货|预留|留一只|留一个|留一下', '帮助核库存及能否预留，确认后回复；客户计划周六到店不等于已经能保证那天有货。不讲工具内部记录。', ['colors', 'stock']),
    ('cleaner', r'清洁剂|去污剂', '成分不明先别用；请提供瓶身标签或成分信息交售后判断。水渍处理仅适用沾水，不把吸干晾干扩大成所有污渍处理。', ['material']),
    ('zipper_fault', r'拉链.{0,12}(?:卡|坏|不顺)|(?:卡|坏).{0,6}拉链', '若已有售后进度先转述；首次报卡顿则收拉合卡顿视频交售后。不推测原因、不教自行排障、不代客户扩写担忧，也不纠正客户该如何看待故障。', ['closure']),
    ('positive_feedback', r'挺舒服|很舒服|背着舒服|背着还不错|顺手|好用|好找|满意|刚好放', '如果客户只是反馈好用，简短接住这份使用感受就结束；不是护理咨询，不顺带护理清单或其他问题。', []),
    ('competitor', r'别家|另一家|其他品牌|别的牌子|另一个牌子|便宜.{0,6}卡夹', '缺竞品资料可自然请发型号、链接或商品页，再对照；不要用自身卖点清单代替比较，也不自述自己不想贬低别人。', ['price', 'material', 'card_slots']),
    ('registration', r'报名|报一下名|登记', '用已知称呼承接；顾问任务的她可作为指代线索，性别不必填。同行称呼若确需登记可直接向客户补问，不是顾问原资料缺口。准备提交不同于已经提交成功。', []),
    ('quantity_offer', r'两只|两件|两个|三只|三件', '按当前是否问优惠及总额作答；问优惠就答政策和总额，不感谢尚未发生的购买，不安排多余确认。', ['price']),
]


def build(value, prepared, brand):
    current = prepared.get('communication', {}).get('latest_text', '')
    text = current + '\n' + value.get('advisor_instruction', '')
    selected = []
    for name, pattern, guidance, fields in TASKS:
        if re.search(pattern, text):
            selected.append(dict(task=name, guidance=guidance, relevant_product_fields=fields))
    focus = prepared.get('answer_context', {}).get('response_scope', {}).get('focus_ids', value.get('product_ids', []))
    return dict(version=VERSION, current_customer_text=current, advisor_task=value.get('advisor_instruction', ''), hints=selected, selected_product_ids=focus, authority='非穷尽任务线索，不是业务事实、不决定资料是否齐全；原问题优先，未命中不阻塞；只取当前问题有关事实，不照抄全部素材')
