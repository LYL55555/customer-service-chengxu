import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import engine
from revalidation import refresh_context,revalidate
from task_materials import build
from answer_context import inspect as inspect_answer
from quality import inspect_messages
from source_review import audit as review_audit
from evidence_sources import candidate_spans

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/focused_generation_v0.18.0_2026-11-05'
REVIEW=json.loads((ROOT/'outputs/independent_output_review_v0.17.0_2026-11-05/REVIEW.json').read_text())


def saved(identity):return json.loads((ROOT/next(c['source'] for c in REVIEW['latest'] if c['case_id']==identity)).read_text())


class FocusedGenerationTests(unittest.TestCase):
    def setUp(self):self.brand=engine.brand_data()

    def prepared(self,chat,scenario='商品推荐',ids=None,background='',related='',profile=None):
        value=engine.clean_input(dict(scenario=scenario,conversation=chat,product_ids=ids or [],client_info=background,related_info=related),self.brand['products'])
        record=dict(input=value,confirmed_context=engine.prepare_context(value),customer_context=profile or {})
        p=refresh_context(record,self.brand);return value,p,p['task_materials']['generation_input']

    def fact_ids(self,context):return {r['source_id'] for r in context['facts']}

    def test_carry_price_only_does_not_get_other_attributes_or_policy(self):
        for chat in ['客户：肩包能斜挎吗，多少钱？','客户：这只轻行肩包怎么背，价格是多少？']:
            _,_,g=self.prepared(chat)
            self.assertEqual(self.fact_ids(g),{'product.P02.price','product.P02.carry_modes','product.P02.strap_adjustable'})
            raw=json.dumps(g,ensure_ascii=False)
            for term in ['维修','退货','登记','防水','origin','loaded_comfort','内尺寸','零钱袋','product.P01','product.P03']:self.assertNotIn(term,raw)

    def test_four_card_fact_has_price_capacity_but_no_irrelevant_limit(self):
        _,_,g=self.prepared('客户：这款卡夹多少钱，四张银行卡放得下吗？',ids=['P03'])
        self.assertEqual(self.fact_ids(g),{'product.P03.price','product.P03.capacity'})
        for word in ['护照','零钱袋','手机','试用','内尺寸']:self.assertNotIn(word,json.dumps(g,ensure_ascii=False))

    def test_positive_feedback_has_no_care_facts_or_next_step(self):
        for text in ['客户：托特用起来挺顺手的，选对了。','客户：这个包我用着很舒服，谢谢。']:
            _,_,g=self.prepared(text,scenario='购后关怀',ids=['P01'])
            self.assertEqual(g['facts'],[]);self.assertEqual(g['task']['necessary_next_steps'],[])
            self.assertEqual(g['task']['mode'],'positive_feedback')

    def test_positive_word_with_real_question_does_not_hide_question(self):
        _,_,g=self.prepared('客户：肩包背着挺顺手的，不过拉链卡顿怎么办？',scenario='购后关怀',ids=['P02'])
        self.assertEqual(g['task']['mode'],'zipper_fault');self.assertTrue(g['task']['necessary_next_steps'])

    def test_price_concern_does_not_retrieve_discount(self):
        _,_,g=self.prepared('客户：肩包有点超出预期，平时只带手机钥匙，适合吗？',ids=['P02'])
        self.assertIn('product.P02.capacity',self.fact_ids(g));self.assertNotIn('policy.4',self.fact_ids(g))
        _,_,offer=self.prepared('客户：肩包贵了些，能优惠一点吗？',ids=['P02'])
        self.assertIn('policy.4',self.fact_ids(offer));self.assertIn('无折扣',json.dumps(offer,ensure_ascii=False))

    def test_event_content_does_not_receive_signup_time_or_location(self):
        raw=saved('N39');p=refresh_context(raw,self.brand);g=p['task_materials']['generation_input'];text=json.dumps(g['facts'],ensure_ascii=False)
        self.assertIn('演示',text)
        for term in ['登记','同行','朋友','2026-11-14','14:00','精品店']:self.assertNotIn(term,text)
        self.assertNotIn('evidence_sources',g)
        rows=p['task_materials']['selection_audit']['selected'];self.assertTrue(rows)
        for row in rows:
            if row['start'] is not None:self.assertEqual(row['source_text'][row['start']:row['end']],row['selected_text'])

    def test_cleaner_keeps_necessary_policy_not_water_care(self):
        _,_,g=self.prepared('客户：家里的去污剂能擦卡夹吗？',scenario='购后关怀',ids=['P03'])
        self.assertIn('policy.5',self.fact_ids(g));s=json.dumps(g,ensure_ascii=False)
        self.assertIn('先不要使用',s);self.assertIn('标签',s)
        for term in ['晾干','吸干','酒精','淋雨','皮革等级']:self.assertNotIn(term,s)

    def test_coin_question_keeps_negative_structural_fact(self):
        _,p,g=self.prepared('客户：卡夹有放硬币的袋子吗？',ids=['P03'])
        self.assertIn('product.P03.coin_pocket',self.fact_ids(g));self.assertIn('无单独零钱袋',json.dumps(g,ensure_ascii=False))
        errors=inspect_messages(['这款没有单独零钱袋。'],self.brand['products'],focus_ids=['P03'],context=dict(value={},prepared=p));self.assertEqual(errors,[])

    def test_stock_not_given_as_confirmed_and_no_extra_catalog(self):
        raw=saved('N21');p=refresh_context(raw,self.brand);g=p['task_materials']['generation_input']
        self.assertEqual(self.fact_ids(g),{'product.P02.colors'});self.assertTrue(g['task']['necessary_next_steps'])
        self.assertIn('确认后回复',json.dumps(g,ensure_ascii=False))
        errors=inspect_messages(['已经为您预留一只，周六来就能看。'],self.brand['products'],focus_ids=['P02'],context=dict(value=raw['input'],prepared=p))
        self.assertTrue(errors)

    def test_latest_use_shift_keeps_chat_profile_and_current_recommendation(self):
        raw=saved('N22');p=refresh_context(raw,self.brand);g=p['task_materials']['generation_input']
        self.assertEqual(g['task']['selected_product_ids'],['P01']);self.assertEqual(len(g['chat']),5)
        self.assertIn('小标识',g['context']['long_term_preferences']['text'])
        self.assertIn('20,000',g['context']['current_budget']['text'])
        self.assertFalse(any('P02' in r['source_id'] for r in g['facts']))
        self.assertNotIn('电脑',json.dumps(g['facts'],ensure_ascii=False))

    def test_quotes_roles_times_and_contact_limit_retained(self):
        v,p,_=self.prepared('客户：只把活动地址发我。',scenario='活动邀请',profile=dict(marketing_opt_out=True))
        p['messages'][0].update(quoted_text='朋友说想买包',sent_at='2026-11-05 09:00');g=build(v,p,self.brand)['generation_input']
        self.assertTrue(g['contact_constraints']['marketing_opt_out']);self.assertEqual(g['chat'][0]['quoted_text'],'朋友说想买包');self.assertEqual(g['chat'][0]['role'],'customer');self.assertIn('sent_at',g['chat'][0])
        errors=inspect_messages(['以后每次活动我都会通知您。'],self.brand['products'],context=dict(value=v,prepared=p));self.assertIn('marketing_after_opt_out',[r['code']for r in errors])

    def test_phone_official_reference_not_recalled_or_forced_measurement(self):
        _,_,g=self.prepared('客户：肩包能斜挎吗？iPhone 15 Pro Max能放进去吗？',ids=['P02'])
        self.assertTrue(any(r['source_id'].startswith('device.')for r in g['facts']))
        self.assertIn('8.25',json.dumps(g,ensure_ascii=False));self.assertIn('product.P02.dimensions_cm',self.fact_ids(g))

    def test_birthday_without_chat_and_simple_price_need_no_budget(self):
        _,_,g=self.prepared('',scenario='生日及节日问候',background='林女士今天生日，发句祝福。')
        self.assertEqual(g['facts'],[]);self.assertFalse(g['task']['necessary_next_steps'])
        v,p,g=self.prepared('客户：肩包多少钱？',ids=['P02'])
        self.assertEqual(p['input_readiness']['state'],'ready');self.assertEqual(self.fact_ids(g),{'product.P02.price'})

    def test_saved_use_can_drive_proactive_recommendation_without_new_form(self):
        _,p,g=self.prepared('',profile=dict(preferences='通勤带A4资料和水杯，喜欢墨黑和小标识。'))
        self.assertEqual(p['input_readiness']['state'],'ready')
        self.assertEqual(g['task']['mode'],'recommendation');self.assertEqual(g['task']['selected_product_ids'],['P01'])
        self.assertIn('product.P01.price',self.fact_ids(g));self.assertIn('product.P01.capacity',self.fact_ids(g))

    def test_wet_care_retrieves_relevant_steps_but_not_cleaner_warning(self):
        _,_,g=self.prepared('客户：包刚才溅到水了，怎么处理？',scenario='购后关怀',ids=['P02'])
        self.assertEqual(g['task']['mode'],'wet_care');s=json.dumps(g['facts'],ensure_ascii=False)
        self.assertIn('吸干',s);self.assertNotIn('清洁剂',s);self.assertNotIn('退货',s)

    def test_actual_generation_request_compact_review_and_internal_evidence_full(self):
        raw=saved('U01');calls=[]
        def model(config,body,audit):
            calls.append(copy.deepcopy(body))
            return copy.deepcopy(raw['quality_review']['parsed_output'] if 'QUALITY_REVIEW_V1' in body['messages'][0]['content'] else raw['parsed_output'])
        with tempfile.TemporaryDirectory()as temp,patch('engine.model_call',side_effect=model):
            result=engine.generate(dict(input=raw['input']),store=engine.RunStore(temp),config=engine.Config('https://api.deepseek.com','fake','fake'),customer_context=raw['customer_context'])
        self.assertEqual(result['status'],'success',result.get('error'));self.assertEqual(len(calls),2)
        generated=json.loads(calls[0]['messages'][1]['content']);reviewed=json.loads(calls[1]['messages'][1]['content'])
        for key in ['confirmed_context','client_context','selected_products','evidence_sources','understanding_draft','business_evidence']:self.assertNotIn(key,generated)
        self.assertNotIn('维修',json.dumps(calls[0],ensure_ascii=False));self.assertNotIn('## 3. 商品目录',calls[0]['messages'][0]['content'])
        self.assertIn('## 3. 商品目录',calls[1]['messages'][0]['content']);self.assertGreater(len(reviewed['evidence_sources']['sources']),50)
        self.assertEqual(result['brand_snapshot'],self.brand['rules']);self.assertTrue(result['generation_materials']['selection_audit']['omitted_source_ids'])
        self.assertEqual(result['result']['messages'],raw['parsed_output']['messages'])

    def test_saved_pause_original_pass_can_deliver_without_regeneration(self):
        raw=saved('N49');r=revalidate(raw)
        self.assertEqual(r['status'],'success',r.get('error'));self.assertEqual(r['parsed_output'],raw['parsed_output']);self.assertEqual(r['quality_review']['parsed_output'],raw['quality_review']['parsed_output'])

    def test_pause_state_requires_source_and_actual_behavior_not_only_labels(self):
        raw=saved('N49');p=refresh_context(raw,self.brand)
        for text in ['好的，先不预留，您慢慢考虑。','明白，这次不帮您留。']:
            self.assertTrue(engine.state_equivalence('comparing','unclear',raw['input'],p,[text]*3)[0])
        for text in ['我先帮您留一只，您再想想。','要不要再来看看肩包？']:
            self.assertFalse(engine.state_equivalence('comparing','unclear',raw['input'],p,[text]*3)[0])
        _,p,_=self.prepared('客户：肩包多少钱？',ids=['P02'])
        self.assertFalse(engine.state_equivalence('comparing','unclear',{},p,['好的。']*3)[0])
        self.assertFalse(engine.state_equivalence('declined','comparing',{},p,['好的。']*3)[0])

    def test_actual_refusal_still_blocks_selling(self):
        _,p,_=self.prepared('客户：不用再推荐了。')
        errors=inspect_messages(['要不要再看看肩包？'],self.brand['products'],expected_state='declined',context=dict(value={},prepared=p))
        self.assertIn('selling_after_decline',[e['code']for e in errors])

    def test_followup_current_task_cannot_be_replaced_by_current_event(self):
        raw=saved('N43');p=refresh_context(raw,self.brand)
        old=raw['parsed_output']['messages'];self.assertTrue(inspect_answer(old,dict(prepared=p)))
        r=revalidate(raw);self.assertEqual(r['status'],'error')
        p['candidate_spans']=candidate_spans(old)
        errors=review_audit(raw['quality_review']['parsed_output'],raw['parsed_output'],p,self.brand['products'],[])
        self.assertIn('reviewer_missed_current_answer',[e['code']for e in errors])
        for text in ['我帮您向门店核实后续类似活动的安排，确认后回复您。','后面的活动我帮您问一下门店，有结果回复您。']:
            self.assertEqual(inspect_answer([text]*3,dict(prepared=p)),[])
        g=p['task_materials']['generation_input'];self.assertEqual(g['facts'],[]);self.assertTrue(g['task']['necessary_next_steps'])

    def test_rephrased_followup_not_case_number(self):
        _,p,g=self.prepared('客户：本场赶不上，后面还会办吗？',scenario='活动邀请',related=saved('N43')['input']['related_info'])
        self.assertEqual(g['task']['mode'],'event_followup');self.assertIn('后续活动',p['answer_context']['topics'])
        self.assertTrue(inspect_answer(['这次活动是11月14日。']*3,dict(prepared=p)))

    def test_weight_retains_only_relevant_unknown_and_no_unrelated_unknown_catalog(self):
        raw=saved('N16');p=refresh_context(raw,self.brand);g=p['task_materials']['generation_input']
        self.assertIn('product.P01.loaded_comfort',self.fact_ids(g));self.assertIn('product.P01.loaded_weight_g',self.fact_ids(g))
        self.assertNotIn('origin',json.dumps(g));self.assertNotIn('opening_dimensions',json.dumps(g))

    def test_unverified_loaded_comfort_is_not_daily_capacity_or_reported_customer_feeling(self):
        _,p,_=self.prepared('客户：托特走二十分钟会沉吗？',ids=['P01'])
        for text in ['托特背起来不会太吃力。','把重物靠里放，肩带受力会更舒服。','托特走路二十分钟问题不大。','空包750克，属于中等偏轻。']:
            self.assertTrue(inspect_messages([text],self.brand['products'],focus_ids=['P01'],context=dict(value={},prepared=p)),text)
        for text in ['日行托特包空包约750克，能装A4资料和水杯。','空包750克，装物后还会增加重量。','不能保证装东西后背起来不累。']:
            self.assertFalse(inspect_messages([text],self.brand['products'],focus_ids=['P01'],context=dict(value={},prepared=p)),text)
        from product_evidence import inspect
        self.assertFalse(inspect('听您说背着轻松就好。',self.brand['products'],['P01'],reference_text='我这几天背着轻松。'))

    def test_cross_sentence_price_reference_uses_candidate_subject_and_span(self):
        row=next(r for r in json.loads((OUT/'CALLS.json').read_text())['results']if r['case_id']=='N22')
        raw=json.loads((OUT/row['record']).read_text());derived=revalidate(raw)
        self.assertEqual(derived['status'],'success',derived.get('error'));self.assertEqual(raw['parsed_output'],derived['parsed_output'])
        for source in ['product.P02.price','product.P03.price']:
            wrong=copy.deepcopy(raw);wrong['quality_review']['parsed_output']['candidate_checks']['reply_1']['source_checks'][3]['source_id']=source
            self.assertEqual(revalidate(wrong)['status'],'error')
        wrong=copy.deepcopy(raw);wrong['parsed_output']['messages'][0]=wrong['parsed_output']['messages'][0].replace('18,800','19,800')
        self.assertEqual(revalidate(wrong)['status'],'error')

    def test_price_cause_is_not_known_price_or_use_judgment(self):
        _,p,_=self.prepared('客户：肩包贵一点，日常带手机合适吗？',ids=['P02'])
        for text in ['贵主要不在容量大，而在它轻便好带。','肩包的价格主要来自皮料成本。']:
            errors=inspect_messages([text],self.brand['products'],focus_ids=['P02'],context=dict(value={},prepared=p));self.assertIn('unsupported_price_cause',[e['code']for e in errors])
        self.assertFalse(inspect_messages(['轻行肩包12,800元，放普通手机、钥匙合适。'],self.brand['products'],focus_ids=['P02'],context=dict(value={},prepared=p)))

    def test_business_followup_is_reply_route_not_advisor_import_gap(self):
        raw=saved('N21');p=refresh_context(raw,self.brand)
        self.assertEqual(p['task_materials']['plan']['reply_route'],'business_followup')
        result=dict(status='needs_advisor',client_state='comparing',messages=[],advisor_note='本地错误替身',missing_information=['请先核库存和能否预留'])
        with self.assertRaises(engine.GenerationError)as error:engine.validate_output(result,context=dict(value=raw['input'],prepared=p))
        self.assertEqual(error.exception.code,'invalid_advisor_request')
        bodies=[]
        def model(config,body,audit):bodies.append(body);raise engine.GenerationError('local_probe_complete','本地检查不发出请求')
        with tempfile.TemporaryDirectory()as temp,patch('engine.model_call',side_effect=model):
            engine.generate(dict(input=raw['input']),engine.RunStore(temp),engine.Config('https://api.deepseek.com','fake','fake'),customer_context=raw['customer_context'])
        fields=bodies[0]['tools'][0]['function']['parameters']['properties']
        self.assertEqual(fields['status']['enum'],['ready']);self.assertNotIn('anyOf',fields['messages']);self.assertEqual(set(fields['messages']['properties']),{'reply_1','reply_2','reply_3'})
        self.assertEqual(fields['missing_information']['maxItems'],0)

    def test_cleaner_stain_advice_still_blocked_when_model_review_passes(self):
        raw=saved('N26');p=refresh_context(raw,self.brand)
        for text in ['先用干净软布干擦污渍。','可以用干软布轻轻拂一下污渍表面。']:
            errors=inspect_messages([text],self.brand['products'],focus_ids=['P03'],context=dict(value=raw['input'],prepared=p))
            self.assertIn('unsupported_stain_treatment',[e['code']for e in errors])
        for text in ['先别用清洁剂，发瓶身标签给我，我交售后确认处理方式。','不建议干擦污点，先别动手。','干擦也不建议，先别处理。']:
            self.assertFalse(inspect_messages([text],self.brand['products'],focus_ids=['P03'],context=dict(value=raw['input'],prepared=p)),text)
        row=next(r for r in json.loads((OUT/'CALLS.json').read_text())['results']if r['case_id']=='N26')
        actual=json.loads((OUT/row['record']).read_text());p=refresh_context(actual,self.brand);result=actual['parsed_output'];p['candidate_spans']=candidate_spans(result['messages'])
        review=copy.deepcopy(actual['quality_review']['parsed_output']);review['verdict']='pass';review['issues']=[]
        errors=review_audit(review,result,p,self.brand['products'],['P03']);self.assertIn('reviewer_missed_care_action',[e['code']for e in errors])

if __name__=='__main__':unittest.main()
